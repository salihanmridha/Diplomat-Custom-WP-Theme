<div class="footer-top">

  <div class="row">

    <div class="large-4 columns">

      <div id="text-2" class="widget widget_text">
        <h3 class="widget-title">About KHN Secretariat</h3>

        <div class="textwidget">
          <p>
            একজন গ্রহপ্রেমিক হয়ে বাংলাদেশি নাগরিক কামরুল হাসান নাসিম মানব সভ্যতায় বেঁচে আছেন।  তিনি ঈশ্বরবাদী।  তিনি মনে করেন, "মহাকাশ কিংবা অজানা কোন ঠিকানায়  অসাধারণ শ্রেনিভুক্ত মনুষ্য প্রাণ সমূহের অস্তিত্বের টিকে থাকার জায়গা মিলবে। সাথে প্রধাণত আরো দুই থেকে তিনটি প্রাণ ( জীন, নূর +) এর একত্রে বসবাসের সুযোগ সৃষ্টি হয়ে নতুন নতুন জীবন অধ্যায়ের গতিপথ নির্ধারিত হবে। যেমন, এই বসুন্ধরা হতে আরেকটি গ্রহে যাওয়া হল। তবে সেটিই আবার অনন্ত গন্তব্য নয়।  সব কিছুই স্রষ্টার হাতে। পৃথিবী নামক গ্রহে হতে স্থানান্তরিত বা গ্রহান্তরীত হওয়ার পর বোঝা যাবে তারপর কী ? "
 সঙ্গত কারণেই কামরুল হাসান নাসিমকে মহান স্রষ্টা তাঁর নিজ সেক্রেটারিয়েট হতে দায়িত্ব পালন করা থেকে বিরত রেখে নিজেই দেখভাল করেন বলে মনে করার সুযোগ সৃষ্টি হয়েছে।  <br><br>
            ঠিক সে কারণেই নাসিম এর কর্মজীবন, সাংস্কৃতিক- রাজনৈতিক- সামাজিক ও আধ্যাত্মিক জীবন রয়েছে, রয়েছে সুনির্দিষ্ট সতেরটি( ১৭) অঙ্গন। এছাড়া আরো কয়েকটি বিশেষ বিশেষ সৃজনশীল কর্ম করার যোগ্যতা তাঁকে মহান স্রষ্টা প্রদান করেছেন। 
যৌক্তিক কারণে মহাবিশ্বের এই মানব প্রতিনিধির সকল কর্মসমুহের অতীত, বর্তমান ও ভবিষ্যত দিক পরিপাটি আঙ্গিকে 'কেএইচএন সেক্রেটারিয়েট' এর মাধ্যমে পরিচালিত হয়ে আসছে। <br><br>
            এই ওয়েব ঠিকানাটি কেএইচএন সেক্রেটারিয়েট এর অনলাইন দিক--- এখানে বসবাস করলেই জানা যাচ্ছে কামরুল হাসান নাসিম এর সব ধরণের কার্যক্রম।  'কেএইচএন সেক্রেটারিয়েট' ফলত কামরুল হাসান নাসিম এর দাপ্তরিক ও আবাসিক কার্যালয়। মহান স্রষ্টার সবিশেষ দায়িত্ব পালনের জন্য তিনি এই গ্রহে নানা ঘাত প্রতিঘাতের মধ্য দিয়েও নিঃশ্বাস নিতে পারছেন বলে ধারণা করা হচ্ছে।  
          </p>
        </div>
      </div>

      <div class="widget widget_social clearfix">

        <h3 class="widget-title">We Are Social</h3>

        <ul class="social-icons">
          <li class="twitter">
            <a target="_blank" href="#">Twitter</a>
          </li>

          <li class="facebook">
            <a target="_blank" href="#">Facebook</a>
          </li>

          <li class="linkedin">
            <a target="_blank" href="#">Linkedin</a>
          </li>

          <li class="pinterest">
            <a target="_blank" href="#">Pinterest</a>
          </li>

          <li class="gplus">
            <a target="_blank" href="#">Google Plus</a>
          </li>

          <li class="instagram">
            <a target="_blank" href="#">Instagram</a>
          </li>

          <li class="dribbble">
            <a target="_blank" href="#">Dribbble</a>
          </li>
        </ul>

      </div>
      <!--/ .widget_social-->
    </div>

    <div class="large-4 columns">

      <div class="widget widget_nav_menu">
        <h3 class="widget-title">Pages</h3>

        <div class="menu-issues-container">
          <ul id="menu-issues" class="menu">
            <?php
              $arr = array(
                'post_type' => 'page',
                'posts_per_page' => 5,
              );

              $latestPages = new WP_Query($arr);
              if ($latestPages->have_posts()):
                while ($latestPages->have_posts()):
                  $latestPages->the_post();
            ?>
            <li>
              <a href="<?php the_permalink(); ?>"><?php the_title(  ); ?></a>
            </li>
            <?php
              endwhile;
              endif;
              wp_reset_postdata();
            ?>
          </ul>
        </div>
      </div>

      <div class="widget widget_nav_menu">
        <h3 class="widget-title">Campaign</h3>

        <div class="menu-campaign-container">
          <ul id="menu-campaign" class="menu">
            <li>
              <a href="about.html">About Us</a>
            </li>
            <li>
              <a href="faq.html">Frequently Asked Questions</a>
            </li>
            <li>
              <a href="events.html">Latest Events</a>
            </li>
            <li>
              <a href="contact.html">Contact Us</a>
            </li>
            <li>
              <a href="people.html">People</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="large-4 columns">
      <div class="widget widget_recent_entries">
        <h3 class="widget-title">Fresh From The Blog</h3>
        <ul>
          <?php
            $arr = array(
              'post_type' => array('post'),
              'posts_per_page' => 4,
            );

            $latestPost = new WP_Query($arr);
            if ($latestPost->have_posts()):
              while ($latestPost->have_posts()):
                $latestPost->the_post();
          ?>
          <li>
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            <span class="post-date"><?php echo get_the_date(); ?></span>
          </li>
          <?php
            endwhile;
            endif;
            wp_reset_postdata();
          ?>
        </ul>
      </div>

    </div>

  </div>
  <!--/ .row-->

</div>
