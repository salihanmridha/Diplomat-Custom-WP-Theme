<div class="large-12 columns">
  <div class="page-title">
    <h1>

      <?php
        if (is_single(  )) {
          echo "Blog";
        }
      ?>
    </h1>

    <div class="breadcrumbs">
      <a href="home.html" title="">Home</a> News
    </div>
    <!--/ .breadcrumbs-->
  </div>
</div>

    <div id="main" class="medium-8 large-8 columns">
      <?php

      //$singleNews = new WP_Query($arr);
        if (have_posts()):
          while (have_posts()):
            the_post();
      ?>
			<div class="post full-width">
        <?php if (has_post_thumbnail()): ?>
				<a href="<?php echo the_post_thumbnail_url(); ?>" class="image-post item-overlay single-image-link">
					<img src="<?php echo the_post_thumbnail_url(); ?>" alt="Congue iure curabitur incididunt consequat">
				</a>
        <?php endif; ?>

				<header class="entry-header">
					<h2 class="entry-title"><?php the_title(  ); ?></h2>

					<div class="entry-meta">
						<span class="posted-on"><a href="#"><?php echo get_the_date(); ?></a></span>
						<span class="byline"><a href="#"><?php the_author(); ?></a></span>
					</div>
				</header>

				<div class="entry-content">



					<p><?php the_content(); ?></p>

				</div>

				<footer class="entry-footer">
					<div class="left">
						<span class="cat-links">
							<a href="#" rel="category tag"><?php the_category( ', ', '', $post->ID ) ?></a>
						</span>
					</div>

				</footer>

			</div>

    <?php endwhile; endif; ?>

    <form method="post" class="contact-form" enctype="multipart/form-data">

					<h2 class="info-title">Personal Information</h2>

					<p class="tmmFormStyling form-input-text">
						<input id="name_1" required="" type="text" name="textinput_1" value=""
							   placeholder="First Name *">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_2" required="" type="text" name="textinput_2" value=""
							   placeholder="Last Name *">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_3" required="" type="text" name="textinput_3" value=""
							   placeholder="Address 1 *">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_4" type="text" name="textinput_4" value="" placeholder="Address 2">
					</p>

					<p class="tmmFormStyling form-select-country">
						<select id="country" class="tmm-country-select" name="location">
							<option value="AX">Aland Islands</option>
							<option value="AL">Albania</option>
							<option value="DZ">Algeria</option>
							<option value="AS">American Samoa</option>
							<option value="AD">Andorra</option>
							<option value="AO">Angola</option>
							<option value="AI">Anguilla</option>
							<option value="AQ">Antarctica</option>
							<option value="AG">Antigua and Barbuda</option>
							<option value="AR">Argentina</option>
							<option value="AM">Armenia</option>
							<option value="AW">Aruba</option>
							<option value="AU">Australia</option>
							<option value="AT">Austria</option>
							<option value="AZ">Azerbaijan</option>
							<option value="BS">Bahamas</option>
							<option value="BH">Bahrain</option>
							<option value="BD">Bangladesh</option>
							<option value="BB">Barbados</option>
							<option value="BE">Belgium</option>
							<option value="BZ">Belize</option>
							<option value="BJ">Benin</option>
							<option value="BM">Bermuda</option>
							<option value="BT">Bhutan</option>
							<option value="BO">Bolivia</option>
							<option value="BA">Bosnia-Herzegovina</option>
							<option value="BW">Botswana</option>
							<option value="BV">Bouvet Island</option>
							<option value="BR">Brazil</option>
							<option value="IO">British Indian Ocean Territory</option>
							<option value="BN">Brunei Darussalam</option>
							<option value="BG">Bulgaria</option>
							<option value="BF">Burkina Faso</option>
							<option value="BI">Burundi</option>
							<option value="KM">Comoros</option>
							<option value="CA">Canada</option>
							<option value="CV">Cape Verde</option>
							<option value="KY">Cayman Islands</option>
							<option value="CF">Central African Republic</option>
							<option value="TD">Chad</option>
							<option value="CL">Chile</option>
							<option value="CN">China</option>
							<option value="CX">Christmas Island</option>
							<option value="CC">Cocos (Keeling) Islands</option>
							<option value="CO">Colombia</option>
							<option value="CD">Democratic Republic of Congo</option>
							<option value="CG">Congo</option>
							<option value="CK">Cook Islands</option>
							<option value="CR">Costa Rica</option>
							<option value="HR">Croatia</option>
							<option value="CY">Cyprus</option>
							<option value="CZ">Czech Republic</option>
							<option value="DK">Denmark</option>
							<option value="DJ">Djibouti</option>
							<option value="DM">Dominica</option>
							<option value="DO">Dominican Republic</option>
							<option value="EC">Ecuador</option>
							<option value="EG">Egypt</option>
							<option value="SV">El Salvador</option>
							<option value="ER">Eriteria</option>
							<option value="EE">Estonia</option>
							<option value="ET">Ethiopia</option>
							<option value="FK">Falkland Islands (Malvinas)</option>
							<option value="FO">Faroe Islands</option>
							<option value="FJ">Fiji</option>
							<option value="FI">Finland</option>
							<option value="FR">France</option>
							<option value="GF">French Guiana</option>
							<option value="PF">French Polynesia</option>
							<option value="TF">French Southern Territories</option>
							<option value="GA">Gabon</option>
							<option value="GM">Gambia</option>
							<option value="GE">Georgia</option>
							<option value="DE">Germany</option>
							<option value="GH">Ghana</option>
							<option value="GI">Gibraltar</option>
							<option value="GR">Greece</option>
							<option value="GL">Greenland</option>
							<option value="GD">Grenada</option>
							<option value="GP">Guadeloupe</option>
							<option value="GU">Guam</option>
							<option value="GT">Guatemala</option>
							<option value="GG">Guernsey</option>
							<option value="GN">Guinea</option>
							<option value="GW">Guinea Bissau</option>
							<option value="GY">Guyana</option>
							<option value="HM">Heard Island / McDonald Islands</option>
							<option value="VA">Holy See (Vatican)</option>
							<option value="HN">Honduras</option>
							<option value="HK">Hong Kong</option>
							<option value="HU">Hungary</option>
							<option value="IS">Iceland</option>
							<option value="IN">India</option>
							<option value="ID">Indonesia</option>
							<option value="IE">Ireland</option>
							<option value="IM">Isle of Man</option>
							<option value="IL">Israel</option>
							<option value="IT">Italy</option>
							<option value="JM">Jamaica</option>
							<option value="JP">Japan</option>
							<option value="JE">Jersey</option>
							<option value="JO">Jordan</option>
							<option value="KZ">Kazakhstan</option>
							<option value="KE">Kenya</option>
							<option value="KI">Kiribati</option>
							<option value="KR">Korea, Republic of</option>
							<option value="KW">Kuwait</option>
							<option value="KG">Kyrgyzstan</option>
							<option value="LA">Laos</option>
							<option value="LV">Latvia</option>
							<option value="LS">Lesotho</option>
							<option value="LI">Liechtenstein</option>
							<option value="LT">Lithuania</option>
							<option value="LU">Luxembourg</option>
							<option value="MO">Macao</option>
							<option value="MK">Macedonia</option>
							<option value="MG">Madagascar</option>
							<option value="MW">Malawi</option>
							<option value="MY">Malaysia</option>
							<option value="MV">Maldives</option>
							<option value="ML">Mali</option>
							<option value="MT">Malta</option>
							<option value="MH">Marshall Islands</option>
							<option value="MQ">Martinique</option>
							<option value="MR">Mauritania</option>
							<option value="MU">Mauritius</option>
							<option value="YT">Mayotte</option>
							<option value="MX">Mexico</option>
							<option value="FM">Micronesia, Federated States of</option>
						</select>
					</p>

					<p class="tmmFormStyling form-input-city">
						<input id="city" type="text" name="city" value="" placeholder="City ">
					</p>

					<div class="row tmmFormStyling">

						<div class="large-6 columns">
							<p class="tmmFormStyling form-select-state">
								<select id="state" class="tmm-state-select" name="state">
									<option value="AL">Alabama</option>
									<option value="AK">Alaska</option>
									<option value="AS">American Samoa</option>
									<option value="AZ">Arizona</option>
									<option value="AR">Arkansas</option>
									<option value="CA">California</option>
									<option value="CO">Colorado</option>
									<option value="CT">Connecticut</option>
									<option value="DE">Delaware</option>
									<option value="DC">District of Columbia</option>
									<option value="FM">Federated States of Micronesia</option>
									<option value="FL">Florida</option>
									<option value="GA">Georgia</option>
									<option value="GU">Guam</option>
									<option value="HI">Hawaii</option>
									<option value="ID">Idaho</option>
									<option value="IL">Illinois</option>
									<option value="IN">Indiana</option>
									<option value="IA">Iowa</option>
									<option value="KS">Kansas</option>
									<option value="KY">Kentucky</option>
									<option value="LA">Louisiana</option>
									<option value="ME">Maine</option>
									<option value="MH">Marshall Islands</option>
									<option value="MD">Maryland</option>
									<option value="MA">Massachusetts</option>
									<option value="MI">Michigan</option>
									<option value="MN">Minnesota</option>
									<option value="MS">Mississippi</option>
									<option value="MO">Missouri</option>
									<option value="MT">Montana</option>
									<option value="NE">Nebraska</option>
									<option value="NV">Nevada</option>
									<option value="NH">New Hampshire</option>
									<option value="NJ">New Jersey</option>
									<option value="NM">New Mexico</option>
									<option value="NY">New York</option>
									<option value="NC">North Carolina</option>
									<option value="ND">North Dakota</option>
									<option value="MP">Northern Mariana Islands</option>
									<option value="OH">Ohio</option>
									<option value="OK">Oklahoma</option>
									<option value="OR">Oregon</option>
									<option value="PW">Palau</option>
									<option value="PA">Pennsylvania</option>
									<option value="PR">Puerto Rico</option>
									<option value="RI">Rhode Island</option>
									<option value="SC">South Carolina</option>
									<option value="SD">South Dakota</option>
									<option value="TN">Tennessee</option>
									<option value="TX">Texas</option>
									<option value="UT">Utah</option>
									<option value="VT">Vermont</option>
									<option value="VI">Virgin Islands</option>
									<option value="VA">Virginia</option>
									<option value="WA">Washington</option>
									<option value="WV">West Virginia</option>
									<option value="WI">Wisconsin</option>
									<option value="WY">Wyoming</option>
									<option value="AA">Armed Forces Americas</option>
									<option value="AE">Armed Forces</option>
									<option value="AP">Armed Forces Pacific</option>
								</select>
							</p>
						</div>

						<div class="large-6 columns">
							<p class="tmmFormStyling form-input-zip">
								<input id="zip" type="text" name="zip" value="" placeholder="Zip Code ">
							</p>
						</div>

					</div>

					<p class="tmmFormStyling form-input-text">
						<input id="name_5" type="text" name="textinput_1" value="" placeholder="Daytime Phone Number">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_6" type="text" name="textinput_2" value="" placeholder="Evening Phone Number">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_7" type="text" name="textinput_3" value=""
							   placeholder="Mobile Phone/Pager Number">
					</p>

					<p class="tmmFormStyling form-input-text">
						<input id="name_8" type="text" name="textinput_4" value="" placeholder="Fax">
					</p>

					<p class="tmmFormStyling form-input-email">
						<input id="email" required="" type="email" name="email" value="" placeholder="Your Email *">
					</p>

					<h2 class="info-title">Please tell us how you can help</h2>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_0" type="checkbox" name="checkbox" value="cb_0" class="tmm-checkbox">
						<label for="cb_0">I'll help a local campaign</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_1" type="checkbox" name="checkbox" value="cb_1" class="tmm-checkbox">
						<label for="cb_1">I'll help organize local events</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_2" type="checkbox" name="checkbox" value="cb_2" class="tmm-checkbox">
						<label for="cb_2">I'll help with major mailings</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_3" type="checkbox" name="checkbox" value="cb_3" class="tmm-checkbox">
						<label for="cb_3">I'll make phone calls</label>
					</p>

					<h6 class="form-title">Other</h6>

					<p class="tmmFormStyling form-textarea">
						<textarea name="checkbox"></textarea>
					</p>

					<h2 class="info-title">Please tell us which issues most interest you</h2>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_4" type="checkbox" name="checkbox552c46d67bc20[]" value="cb_0"
							   class="tmm-checkbox">
						<label for="cb_4">Social Security</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_5" type="checkbox" name="checkbox552c46d67bc20[]" value="cb_1"
							   class="tmm-checkbox">
						<label for="cb_5">Internet Issues</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_6" type="checkbox" name="checkbox" value="cb_2" class="tmm-checkbox">
						<label for="cb_6">Health Care</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_7" type="checkbox" name="checkbox" value="cb_3" class="tmm-checkbox">
						<label for="cb_7">Education</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_8" type="checkbox" name="checkbox" value="cb_4" class="tmm-checkbox">
						<label for="cb_8">Personal Liberty</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_9" type="checkbox" name="checkbox" value="cb_5" class="tmm-checkbox">
						<label for="cb_9">Foreign Policy</label>
					</p>

					<p class="tmmFormStyling form-checkbox">
						<input id="cb_10" type="checkbox" name="checkbox" value="cb_6" class="tmm-checkbox">
						<label for="cb_10">Government Regulation</label>
					</p>

					<h6 class="form-title">Other</h6>

					<p class="tmmFormStyling form-textarea">
						<textarea name="checkbox"></textarea>
					</p>

					<div class="clear"></div>

					<p class="tmmFormStyling form-submit">
						<button class="button middle default-blue" type="submit">Submit</button>
					</p>

				</form>
			<!--/ .post-->

			<div class="social-shares">
				<ul class="social-icons">
					<li class="twitter">
						<a href="#" target="_blank" title="Twitter">Twitter</a>
					</li>
					<li class="facebook">
						<a href="#" target="_blank" title="Facebook">Facebook</a>
					</li>
					<li class="pinterest">
						<a href="#" target="_blank" title="Pinterest">Pinterest</a>
					</li>
					<li class="gplus">
						<a href="#" target="_blank" title="Google+">Google+</a>
					</li>
					<li class="rss">
						<a href="#" target="_blank" title="RSS">RSS</a>
					</li>
				</ul>
			</div>

		</div>
