<?php
  function news_custom_taxonomies(){
    //custom taxonomy for feature news post type

    //add new taxonomy hierarchical
    $labels = array(
      'name' => 'News Categories',
      'singular_name' => 'News Category',
      'search_items' => 'Search News Category',
      'all_items' => 'All News Category',
      'parent_item' => 'Parent News Category',
      'parent_item_colon' => 'Parent News Category:',
      'edit_item' => 'Edit News Category',
      'update_item' => 'Update News Category',
      'add_new_item' => 'Add New News Category',
      'new_item_name' => 'New News Category Name',
      'menu_name' => 'News Category',
    );

    $args = array(
      'hierarchical' => true,
      'labels' => $labels,
      'show_ui' => true,
      'show_admin_column' => true,
      'query_var' => true,
      'rewrite' => array('slug' => 'news-category')
    );

    register_taxonomy( 'news-category', array('news'), $args );

    $parent_term = term_exists( 'world', 'news-category' ); // array is returned if taxonomy is given
    if (!$parent_term) {
      $parent_term_id = $parent_term['term_id']; // get numeric term id
      wp_insert_term(
        'World', // the term
        'news-category', // the taxonomy
        array(
          'description'=> 'Default Category for News Post Type',
          'slug' => 'world',
          'parent'=> $parent_term_id
        )
      );
    }



  }

  add_action( 'init',  'news_custom_taxonomies');




  function album_custom_taxonomies(){
    //custom taxonomy for album post type

    //add new taxonomy hierarchical
    $labels = array(
      'name' => 'Album Categories',
      'singular_name' => 'Album Category',
      'search_items' => 'Search Album Category',
      'all_items' => 'All Album Category',
      'parent_item' => 'Parent Album Category',
      'parent_item_colon' => 'Parent Album Category:',
      'edit_item' => 'Edit Album Category',
      'update_item' => 'Update Album Category',
      'add_new_item' => 'Add New Album Category',
      'new_item_name' => 'New Album Category Name',
      'menu_name' => 'Album Category',
    );

    $args = array(
      'hierarchical' => true,
      'labels' => $labels,
      'show_ui' => true,
      'show_admin_column' => true,
      'query_var' => true,
      'rewrite' => array('slug' => 'album-category')
    );

    register_taxonomy( 'album-category', array('album'), $args );




  }

  add_action( 'init',  'album_custom_taxonomies');

  function event_custom_taxonomies(){
    //custom taxonomy for event post type

    //add new taxonomy hierarchical
    $labels = array(
      'name' => 'Events Categories',
      'singular_name' => 'Event Category',
      'search_items' => 'Search Event Category',
      'all_items' => 'All Event Category',
      'parent_item' => 'Parent Event Category',
      'parent_item_colon' => 'Parent Event Category:',
      'edit_item' => 'Edit Event Category',
      'update_item' => 'Update Event Category',
      'add_new_item' => 'Add New Event Category',
      'new_item_name' => 'New Event Category Name',
      'menu_name' => 'Event Category',
    );

    $args = array(
      'hierarchical' => true,
      'labels' => $labels,
      'show_ui' => true,
      'show_admin_column' => true,
      'query_var' => true,
      'rewrite' => array('slug' => 'event-category')
    );

    register_taxonomy( 'event-category', array('events'), $args );




  }

  add_action( 'init',  'event_custom_taxonomies');
?>
