<?php
//all style file and script files included
require get_template_directory() . '/inc/function-enqueue.php';
//Theme Supports
require get_template_directory() . '/inc/theme-support.php';
//custom post type
require get_template_directory() . '/inc/custom-post-type.php';
//custom taxonomies
require get_template_directory() . '/inc/custom-taxonomies.php';
//custom taxonomies
require get_template_directory() . '/inc/custom-events-meta-boxes.php';
//custom taxonomies
require get_template_directory() . '/ajax.php';
