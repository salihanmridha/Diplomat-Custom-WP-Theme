<div class="footer-top">

  <div class="row">

    <div class="large-4 columns">

      <div id="text-2" class="widget widget_text">
        <h3 class="widget-title">About Salihan Mridha</h3>

        <div class="textwidget">
          <p>
            Thanks for visit my website. I am a professional Web Designer & Developer, working as a freelancer since 2012. I am graduated in Business Information and Technology from Greenwich University, UK. I have over 3+ years of work experience as a freelancer in PHP, Laravel and Wordpress web development work. <br><br>
            I build bespoke websites to help my clients push their businesses further online. My expertise is in PHP, Laravel, Wordpress and E-commerce Web development work. If you'd like me to get involved with helping your business grow, I'm all ears! <br><br>
            I'm confident, naturally curious and seeking to learn new things and like to do problem solving tasks and perpetually improving my chops.
          </p>
        </div>
      </div>

      <div class="widget widget_social clearfix">

        <h3 class="widget-title">We Are Social</h3>

        <ul class="social-icons">
          <li class="twitter">
            <a target="_blank" href="#">Twitter</a>
          </li>

          <li class="facebook">
            <a target="_blank" href="#">Facebook</a>
          </li>

          <li class="linkedin">
            <a target="_blank" href="#">Linkedin</a>
          </li>

          <li class="pinterest">
            <a target="_blank" href="#">Pinterest</a>
          </li>

          <li class="gplus">
            <a target="_blank" href="#">Google Plus</a>
          </li>

          <li class="instagram">
            <a target="_blank" href="#">Instagram</a>
          </li>

          <li class="dribbble">
            <a target="_blank" href="#">Dribbble</a>
          </li>
        </ul>

      </div>
      <!--/ .widget_social-->
    </div>

    <div class="large-4 columns">

      <div class="widget widget_nav_menu">
        <h3 class="widget-title">Pages</h3>

        <div class="menu-issues-container">
          <ul id="menu-issues" class="menu">
            <?php
              $arr = array(
                'post_type' => 'page',
                'posts_per_page' => 5,
              );

              $latestPages = new WP_Query($arr);
              if ($latestPages->have_posts()):
                while ($latestPages->have_posts()):
                  $latestPages->the_post();
            ?>
            <li>
              <a href="<?php the_permalink(); ?>"><?php the_title(  ); ?></a>
            </li>
            <?php
              endwhile;
              endif;
              wp_reset_postdata();
            ?>
          </ul>
        </div>
      </div>

      <div class="widget widget_nav_menu">
        <h3 class="widget-title">Campaign</h3>

        <div class="menu-campaign-container">
          <ul id="menu-campaign" class="menu">
            <li>
              <a href="about.html">About Us</a>
            </li>
            <li>
              <a href="faq.html">Frequently Asked Questions</a>
            </li>
            <li>
              <a href="events.html">Latest Events</a>
            </li>
            <li>
              <a href="contact.html">Contact Us</a>
            </li>
            <li>
              <a href="people.html">People</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="large-4 columns">
      <div class="widget widget_recent_entries">
        <h3 class="widget-title">Fresh From The Blog</h3>
        <ul>
          <?php
            $arr = array(
              'post_type' => array('post'),
              'posts_per_page' => 4,
            );

            $latestPost = new WP_Query($arr);
            if ($latestPost->have_posts()):
              while ($latestPost->have_posts()):
                $latestPost->the_post();
          ?>
          <li>
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            <span class="post-date"><?php echo get_the_date(); ?></span>
          </li>
          <?php
            endwhile;
            endif;
            wp_reset_postdata();
          ?>
        </ul>
      </div>

    </div>

  </div>
  <!--/ .row-->

</div>
