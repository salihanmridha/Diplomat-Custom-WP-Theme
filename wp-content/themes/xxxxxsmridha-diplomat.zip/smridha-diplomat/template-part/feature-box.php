<div class="medium-12 large-12 columns">

  <ul class="block-with-icons">
    <li>
      <a href="issues.html">
        <i class="icon-group"></i>
        <h5>Campaign</h5>
        <span>Lorem Ipsum Dolor Consectetur</span>
      </a>
    </li>
    <li>
      <a href="volunteer.html">
        <i class="icon-thumbs-up-4"></i>
        <h5>Accessibility</h5>
        <span>Lorem Ipsum Dolor Consectetur</span>
      </a>
    </li>
    <li>
      <a href="event-calendar.html">
        <i class="icon-calendar-inv"></i>
        <h5>Calendar</h5>
        <span>Lorem Ipsum Dolor Consectetur</span>
      </a>
    </li>
  </ul>
</div>
