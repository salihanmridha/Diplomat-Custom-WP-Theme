<div class="footer-bottom">

  <div class="row">

    <div class="large-6 columns">
      <div class="copyright">
        Copyright © 2019. All rights reserved
      </div>
    </div>

    <div class="large-3 large-offset-3 columns">
      <div class="developed">
        Developed by <a target="_blank" href="https://www.redcorex.com/">Redcorex</a>
      </div>
    </div>

  </div>
  <!--/ .row-->

</div>
<!--/ .footer-bottom-->

</footer>
<!--/ #footer-->

<!-- - - - - - - - END FOOTER - - - - - - - -->

</div>
<!--/ #wrapper-->

<!-- - - - - - - - END WRAPPER - - - - - - - -->
</body>
<?php wp_footer(); ?>
<!-- Mirrored from html.webtemplatemasters.com by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Jan 2019 16:33:54 GMT -->
</html>
