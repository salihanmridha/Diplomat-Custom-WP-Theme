<div class="footer-top">

  <div class="row">

    <div class="large-4 columns">

      <div id="text-2" class="widget widget_text">
        <h3 class="widget-title">About KHN Secretariat</h3>

        <div class="textwidget">
          <p>
            Kamrul Hasan Nasim, Bangladeshi  citizen has been living in the  human civilization who is also a  lover of planet at the same time. He is  a Theist. He believes  that  the existence of extraordinary categorized human lives   will get a survival  suit in the Space or unknown addresses. At the same time, after created the  opportunities of living together of  mainly two or three lives (Jeen, Noor+), the direction of the new life chapter will be determined.
For example, this is to go to another planet from the world. But it is not an eternal destination, everything is in the hands of God. After being transmitted from the planet “ Earth” , It will be understood what can  happen then?
  For the sake of reason, the opportunity has been created to think that the great creator,  take care himself after stopped Kamrul Hasan Nasim from his duty as secretariat. Exactly for this reason, Mr. Nasim has cultural, political, social and spiritual life in his career as well as specific seventeen sectors.....
          </p>
        </div>
      </div>

      
      <!--/ .widget_social-->
    </div>

    <div class="large-4 columns">

      <div class="widget widget_nav_menu">
        <h3 class="widget-title">.....</h3>
		<p>
			Besides, the great creator  has given  him the ability to do some special creative works. For the sake of reason, the all  past, present and future aspects of all the work of this “human representative of the world”  are being carried on by the KHN Secretariat. <br><br>
            This web address is the online direction of KHN Secretariat ---  all activities of Kamrul Hasan Nasim can be known if you stay here.  'KHN Secretariat', is mainly  official and residential office of  Kamrul Hasan Nasim. It is believed that he could breathe through various  waves of intensity   on this planet in order to perform the best of the great creator.  
		  </p>
        
      </div>

      
    </div>

    <div class="large-4 columns">
      <div class="widget widget_nav_menu">
        <h3 class="widget-title">Important Links</h3>

        <div class="menu-campaign-container">
          <ul id="menu-campaign" class="menu">
            <li>
              <a href="http://www.khnsecretariat.com/about-us/"></a>
            </li>
			  <li>
              <a href="http://www.khnsecretariat.com/contact-us/">Contact Us</a>
            </li>
            <li>
              <a href="#">Questions</a>
            </li>
            <li>
              <a href="events.html">Latest Events</a>
            </li>
            
                      </ul>
        </div>
      </div>

    </div>

  </div>
  <!--/ .row-->

</div>
